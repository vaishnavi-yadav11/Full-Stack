package OPPs;

public class Test {
    public static void main(String[] args) {
        ATM atm=new ATM("Ayush",100000);
        atm.showBal(); //info
        //atm.balance=10; //wrong
        atm.showBal(); //info
    }
}
