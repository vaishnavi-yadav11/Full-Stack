package OPPs;

public class CalTest {
    public static void main(String[] args) {
        Calculator cal=new Calculator();
        int res= cal.add(10,10);
        System.out.println(res);
    }
}
