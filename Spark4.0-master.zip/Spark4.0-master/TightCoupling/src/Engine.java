public interface Engine {
    public void start();
}
