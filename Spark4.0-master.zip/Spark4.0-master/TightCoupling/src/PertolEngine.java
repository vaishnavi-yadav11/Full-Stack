public class PertolEngine implements Engine {
    public void start()
    {
        System.out.println("petrol engine started....");
    }
}
