public class DieselEngine implements Engine{
    public void start()
    {
        System.out.println("Diesel engine started....");
    }
}
