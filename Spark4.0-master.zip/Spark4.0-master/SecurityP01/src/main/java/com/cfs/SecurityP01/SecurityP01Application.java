package com.cfs.SecurityP01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityP01Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityP01Application.class, args);
	}

}
