public class Thar extends Vechicle{
    Thar(String brand) {
        super(brand); //parent class constructor
        //
    }

    @Override
    void start() {

    }

    public static void main(String[] args) {
        //Vechicle c=new Vechicle();

    }

}
