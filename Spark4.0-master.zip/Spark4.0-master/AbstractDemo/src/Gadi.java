public interface Gadi {
    void start();
    void stop();
}
