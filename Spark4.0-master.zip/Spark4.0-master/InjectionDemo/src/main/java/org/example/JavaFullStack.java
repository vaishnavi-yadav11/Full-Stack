package org.example;

public class JavaFullStack implements Course{
    public int enroll() {
        return 1;
    }
}
