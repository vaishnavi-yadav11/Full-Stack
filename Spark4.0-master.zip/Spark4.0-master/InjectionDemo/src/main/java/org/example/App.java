package org.example;

public class App {
    public static void main(String[] args) {
        Studnet s=new Studnet();
        s.course=new DSA();
        s.study();
    }
}
