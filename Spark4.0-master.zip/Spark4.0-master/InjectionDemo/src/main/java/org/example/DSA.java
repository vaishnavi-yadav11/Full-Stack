package org.example;

public class DSA implements Course{
    public int enroll() {
        return 1;
    }
}
