package org.example;

public interface Course {

    public int enroll();
}
