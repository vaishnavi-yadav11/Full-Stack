package com.cfs.SecurityP04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityP04Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityP04Application.class, args);
	}

}
