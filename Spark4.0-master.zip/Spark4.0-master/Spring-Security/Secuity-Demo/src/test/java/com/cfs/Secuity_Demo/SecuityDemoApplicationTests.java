package com.cfs.Secuity_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
