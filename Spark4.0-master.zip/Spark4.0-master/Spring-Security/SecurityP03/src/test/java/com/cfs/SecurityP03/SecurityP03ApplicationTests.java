package com.cfs.SecurityP03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityP03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
