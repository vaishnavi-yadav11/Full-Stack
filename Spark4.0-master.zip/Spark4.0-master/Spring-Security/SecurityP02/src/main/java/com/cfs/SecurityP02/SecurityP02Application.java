package com.cfs.SecurityP02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityP02Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityP02Application.class, args);
	}

}
