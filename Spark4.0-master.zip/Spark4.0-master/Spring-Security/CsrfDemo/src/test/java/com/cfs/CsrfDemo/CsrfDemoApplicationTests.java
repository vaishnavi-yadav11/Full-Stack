package com.cfs.CsrfDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsrfDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
