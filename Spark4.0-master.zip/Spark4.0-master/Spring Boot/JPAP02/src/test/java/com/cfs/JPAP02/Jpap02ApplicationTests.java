package com.cfs.JPAP02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpap02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
