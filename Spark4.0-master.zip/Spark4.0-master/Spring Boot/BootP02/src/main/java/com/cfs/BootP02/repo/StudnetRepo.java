package com.cfs.BootP02.repo;

import org.springframework.stereotype.Repository;

@Repository
public class StudnetRepo {

    public String getStudentData()
    {
        return "Hello Arjun....";
    }
}
