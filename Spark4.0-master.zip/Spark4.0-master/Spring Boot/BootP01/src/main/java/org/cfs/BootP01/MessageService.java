package org.cfs.BootP01;

public interface MessageService {
    String sendMessage();
}
