package org.cfs;

public interface Engine {

    public int start();
}
