package Custom;

public class InsufficentBalExeption extends Exception{
    public InsufficentBalExeption(String msg)
    {
        super(msg);
    }
}
