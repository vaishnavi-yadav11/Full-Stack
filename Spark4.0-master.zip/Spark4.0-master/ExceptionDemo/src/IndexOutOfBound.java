public class IndexOutOfBound {
    public static void main(String[] args) {
        int[] arr={10,11};
        System.out.println(arr[4]);
    }
}
